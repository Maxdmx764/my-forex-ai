
import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";
import OpenAI from "openai";

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.resolve("./data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const DB_FILE = path.join(DATA_DIR, "strategies.json");
const HISTORY_FILE = path.join(DATA_DIR, "history.json");
const MONITOR_FILE = path.join(DATA_DIR, "monitor.json");

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";
const TWELVE_DATA_API_KEY = process.env.TWELVE_DATA_API_KEY || "";
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || "";

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return { vectorStoreId: null, files: [] }; }
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
function loadHistory() {
  try { return JSON.parse(fs.readFileSync(HISTORY_FILE, "utf8")); }
  catch { return []; }
}
function saveHistory(items) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(items, null, 2));
}
function loadMonitor() {
  try { return JSON.parse(fs.readFileSync(MONITOR_FILE, "utf8")); }
  catch { return { enabled: false, symbols: [], intervalSeconds: 60, lastRun: null, lastSignals: [] }; }
}
function saveMonitor(x) {
  fs.writeFileSync(MONITOR_FILE, JSON.stringify(x, null, 2));
}

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 25 * 1024 * 1024 }
});

async function ensureVectorStore() {
  const db = loadDB();
  if (db.vectorStoreId) return db.vectorStoreId;

  const vs = await client.vectorStores.create({
    name: "My Forex AI Strategy Library"
  });
  db.vectorStoreId = vs.id;
  saveDB(db);
  return vs.id;
}

async function waitForVectorFile(vectorStoreId, vectorFileId, timeoutMs = 120000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const item = await client.vectorStores.files.retrieve(vectorStoreId, vectorFileId);
    if (item.status === "completed") return item;
    if (item.status === "failed" || item.status === "cancelled") return item;
    await new Promise(r => setTimeout(r, 2000));
  }
  return await client.vectorStores.files.retrieve(vectorStoreId, vectorFileId);
}

function selectedFileIds(db, ids) {
  if (!Array.isArray(ids) || ids.length === 0) return null;
  const allowed = new Set(db.files.filter(x => x.enabled !== false).map(x => x.id));
  return ids.filter(x => allowed.has(x));
}

app.get("/health", (req, res) => res.json({ ok: true, model: MODEL }));


app.get("/monitor", (req, res) => res.json(loadMonitor()));

app.post("/monitor", async (req, res) => {
  const current = loadMonitor();
  const next = {
    ...current,
    enabled: !!req.body.enabled,
    symbols: Array.isArray(req.body.symbols) ? req.body.symbols : current.symbols,
    timeframes: Array.isArray(req.body.timeframes) ? req.body.timeframes : (current.timeframes || ["M5"]),
    intervalSeconds: Math.max(30, Number(req.body.intervalSeconds || current.intervalSeconds || 60))
  };
  saveMonitor(next);
  res.json(next);
});

app.post("/monitor/run-once", async (req, res) => {
  try {
    const output = await runMonitorOnce();
    res.json(output);
  } catch (e) {
    res.status(500).json({ error: e?.message || "Monitor run failed" });
  }
});




app.get("/market", async (req, res) => {
  try {
    if (!TWELVE_DATA_API_KEY) return res.status(400).json({ error: "TWELVE_DATA_API_KEY is not configured." });
    const symbol = req.query.symbol || "EUR/USD";
    const interval = req.query.interval || "5min";
    const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&outputsize=100&apikey=${encodeURIComponent(TWELVE_DATA_API_KEY)}`;
    const r = await fetch(url);
    const data = await r.json();
    if (!r.ok || data.status === "error") return res.status(502).json({ error: data.message || "Market data request failed." });
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e?.message || "Market data failed" });
  }
});

app.get("/market/price", async (req, res) => {
  try {
    if (!TWELVE_DATA_API_KEY) return res.status(400).json({ error: "TWELVE_DATA_API_KEY is not configured." });
    const symbol = req.query.symbol || "EUR/USD";
    const url = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(symbol)}&apikey=${encodeURIComponent(TWELVE_DATA_API_KEY)}`;
    const r = await fetch(url);
    const data = await r.json();
    if (!r.ok || data.status === "error") return res.status(502).json({ error: data.message || "Price request failed." });
    res.json({ symbol, price: data.price, timestamp: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Price failed" });
  }
});

app.get("/telegram/status", (req, res) => {
  res.json({ configured: !!(TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) });
});

app.post("/telegram/test", async (req, res) => {
  try {
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
      return res.status(400).json({ error: "Telegram is not configured on the backend." });
    }
    const text = req.body.text || "My Forex AI V9 test signal.";
    const r = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text })
    });
    const data = await r.json();
    if (!r.ok || !data.ok) return res.status(502).json({ error: data.description || "Telegram send failed." });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Telegram failed" });
  }
});

app.get("/strategies", (req, res) => {
  const db = loadDB();
  res.json({
    vectorStoreId: db.vectorStoreId,
    files: db.files
  });
});

app.post("/strategies/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const vectorStoreId = await ensureVectorStore();
    const uploaded = await client.files.create({
      file: fs.createReadStream(req.file.path),
      purpose: "assistants"
    });

    const vsFile = await client.vectorStores.files.create(vectorStoreId, {
      file_id: uploaded.id,
      attributes: { enabled: true, local_id: uploaded.id }
    });

    const finalStatus = await waitForVectorFile(vectorStoreId, vsFile.id);

    const db = loadDB();
    const record = {
      id: uploaded.id,
      vectorStoreFileId: vsFile.id,
      filename: req.file.originalname,
      status: finalStatus.status,
      enabled: true,
      uploadedAt: new Date().toISOString()
    };
    db.files.push(record);
    saveDB(db);

    fs.unlink(req.file.path, () => {});
    res.json(record);
  } catch (e) {
    console.error(e);
    if (req.file?.path) fs.unlink(req.file.path, () => {});
    res.status(500).json({ error: e?.message || "Upload failed" });
  }
});

app.get("/strategies/status", async (req, res) => {
  try {
    const db = loadDB();
    if (!db.vectorStoreId) return res.json({ vectorStoreId: null, files: [] });

    const files = [];
    for (const f of db.files) {
      try {
        const x = await client.vectorStores.files.retrieve(db.vectorStoreId, f.vectorStoreFileId);
        files.push({ ...f, status: x.status });
      } catch {
        files.push(f);
      }
    }
    db.files = files;
    saveDB(db);
    res.json({ vectorStoreId: db.vectorStoreId, files });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Status failed" });
  }
});


app.patch("/strategies/:fileId", async (req, res) => {
  try {
    const db = loadDB();
    const f = db.files.find(x => x.id === req.params.fileId);
    if (!f) return res.status(404).json({ error: "Strategy file not found" });
    if (typeof req.body.enabled !== "boolean") {
      return res.status(400).json({ error: "enabled must be true or false" });
    }
    f.enabled = req.body.enabled;
    if (db.vectorStoreId && f.vectorStoreFileId) {
      await client.vectorStores.files.update(db.vectorStoreId, f.vectorStoreFileId, {
        attributes: { enabled: f.enabled === true, local_id: f.id }
      });
    }
    saveDB(db);
    res.json(f);
  } catch (e) {
    res.status(500).json({ error: e?.message || "Update failed" });
  }
});

app.delete("/strategies/:fileId", async (req, res) => {
  try {
    const db = loadDB();
    if (!db.vectorStoreId) return res.status(404).json({ error: "No vector store" });

    const f = db.files.find(x => x.id === req.params.fileId);
    if (!f) return res.status(404).json({ error: "Strategy file not found" });

    await client.vectorStores.files.delete(db.vectorStoreId, f.vectorStoreFileId);
    try { await client.files.delete(f.id); } catch {}

    db.files = db.files.filter(x => x.id !== f.id);
    saveDB(db);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e?.message || "Delete failed" });
  }
});

const SYSTEM = `
You are My Forex AI, a strategy-based chart analysis assistant.

The user's uploaded files are the source of truth for strategy rules.
Do NOT invent a rule and do NOT silently substitute a different strategy.

Analyze the supplied chart image together with symbol and timeframe.
Use file search to retrieve the relevant rules from the user's uploaded strategy library.

Return exactly this structure:

SIGNAL: BUY / SELL / WAIT

STRATEGY:
<strategy/file used>

ENTRY:
<price or "Not enough information">

STOP LOSS:
<price or "Not enough information">

TAKE PROFIT:
<price/levels or "Not enough information">

RULE CHECK:
- <rule>: PASS/FAIL/UNKNOWN
- <rule>: PASS/FAIL/UNKNOWN

INVALIDATION:
<what would invalidate the setup>

REASON:
<short evidence-based explanation>

SOURCE:
<filename(s) used>

If important information is missing, use WAIT rather than guessing.
Never claim guaranteed profit or certainty.
If multiple uploaded strategies disagree, report the disagreement and use WAIT unless the user explicitly asks to compare them.
This is analysis only; do not place trades.
`;


app.get("/history", (req, res) => {
  res.json({ items: loadHistory().slice(-100).reverse() });
});

app.delete("/history", (req, res) => {
  saveHistory([]);
  res.json({ ok: true });
});

app.post("/analyze", upload.single("chart"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Chart image is required" });

    const db = loadDB();
    if (!db.vectorStoreId) return res.status(400).json({ error: "Upload at least one strategy file first." });

    const symbol = req.body.symbol || "XAUUSD";
    const timeframe = req.body.timeframe || "M5";
    const question = req.body.question || "Analyze this chart using my uploaded strategies.";
    let liveMarketContext = "";
    if (TWELVE_DATA_API_KEY) {
      try {
        const intervalMap = {M1:"1min",M5:"5min",M15:"15min",M30:"30min",H1:"1h",H4:"4h",D1:"1day"};
        const interval = intervalMap[timeframe] || "5min";
        const u = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}&outputsize=50&apikey=${encodeURIComponent(TWELVE_DATA_API_KEY)}`;
        const mr = await fetch(u);
        const md = await mr.json();
        if (mr.ok && md.values) liveMarketContext = `\nLatest market OHLC data from the configured market-data provider:\n${JSON.stringify(md.values.slice(0,20))}`;
      } catch {}
    }
    let requestedIds = null;
    try { requestedIds = req.body.strategyIds ? JSON.parse(req.body.strategyIds) : null; } catch {}
    const ids = selectedFileIds(db, requestedIds);
    const activeCompleted = db.files.filter(x => x.enabled !== false && x.status === "completed");
    if (activeCompleted.length === 0) {
      return res.status(400).json({ error: "No enabled, completed strategy files are available." });
    }

    const mime = req.file.mimetype || "image/png";
    const b64 = fs.readFileSync(req.file.path).toString("base64");

    const filterParts = [{ type: "eq", key: "enabled", value: true }];
    if (ids && ids.length) filterParts.push({ type: "in", key: "local_id", value: ids });
    const tools = [{
      type: "file_search",
      vector_store_ids: [db.vectorStoreId],
      filters: filterParts.length === 1 ? filterParts[0] : { type: "and", filters: filterParts },
      max_num_results: 12
    }];

    const input = [{
      role: "user",
      content: [
        { type: "input_text", text:
          `Symbol: ${symbol}\nTimeframe: ${timeframe}\nQuestion: ${question}\n` +
          (ids ? `Selected strategy file IDs: ${ids.join(", ")}\nUse those files when relevant.\n` : "") +
          "Analyze the attached chart. Do not guess missing prices."
        },
        { type: "input_image", image_url: `data:${mime};base64,${b64}` }
      ]
    }];

    const response = await client.responses.create({
      model: MODEL,
      instructions: SYSTEM,
      tools,
      input
    });

    const text = response.output_text || "No analysis returned.";
    const history = loadHistory();
    history.push({
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      symbol,
      timeframe,
      question,
      strategyIds: ids || [],
      result: text
    });
    saveHistory(history.slice(-100));

    fs.unlink(req.file.path, () => {});
    res.json({
      ok: true,
      model: MODEL,
      result: text
    });
  } catch (e) {
    console.error(e);
    if (req.file?.path) fs.unlink(req.file.path, () => {});
    res.status(500).json({ error: e?.message || "Analysis failed" });
  }
});

app.listen(PORT, () => console.log(`My Forex AI V6 backend running on port ${PORT}`));
