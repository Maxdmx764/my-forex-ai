# Backend setup

1. Run `npm install`.
2. Copy `.env.example` to `.env`.
3. Put your OpenAI API key in `OPENAI_API_KEY`.
4. Optionally configure Twelve Data and Telegram.
5. Run `npm start`.
6. Test `GET /health`.

For production, use HTTPS and keep all API keys on the server. The Android app only stores the backend URL.

OpenAI's current API documentation supports the Responses API, File Search, vector stores, vector-store-file attributes, and filtering by attributes. The backend uses those capabilities to keep disabled strategies out of retrieval. 
