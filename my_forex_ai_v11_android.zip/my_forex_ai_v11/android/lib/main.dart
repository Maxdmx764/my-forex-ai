
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

const defaultApiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

void main() => runApp(const MyForexAI());

class MyForexAI extends StatelessWidget {
  const MyForexAI({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'My Forex AI',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const Home(),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  List<dynamic> history = [];
  String livePrice = '--';
  String marketStatus = 'Not connected';
  bool monitorEnabled = false;
  String monitorStatus = 'Monitoring off';
  final monitorSymbols = TextEditingController(text: 'XAU/USD,EUR/USD');
  final symbol = TextEditingController(text: 'XAUUSD');
  final question = TextEditingController();
  String tf = 'M5';
  String result = '';
  bool busy = false;
  String apiBase = defaultApiBase;
  List<dynamic> files = [];

  Future<void> loadLivePrice() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/market/price?symbol=${Uri.encodeComponent(symbol.text.trim())}'));
      if (r.statusCode == 200) {
        final x = jsonDecode(r.body);
        setState(() { livePrice = x['price']?.toString() ?? '--'; marketStatus = 'Live price updated'; });
      } else {
        setState(() => marketStatus = 'Market data not configured');
      }
    } catch (e) { setState(() => marketStatus = 'Market connection error'); }
  }

  Future<void> loadMonitor() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/monitor'));
      if (r.statusCode == 200) {
        final x = jsonDecode(r.body);
        setState(() {
          monitorEnabled = x['enabled'] == true;
          monitorStatus = monitorEnabled ? 'Monitoring ON' : 'Monitoring OFF';
        });
      }
    } catch (e) { setState(() => monitorStatus = 'Monitor connection error'); }
  }

  Future<void> saveMonitor() async {
    final symbols = monitorSymbols.text.split(',').map((x) => x.trim()).where((x) => x.isNotEmpty).toList();
    try {
      final r = await http.post(Uri.parse('$apiBase/monitor'),
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({
          'enabled': monitorEnabled,
          'symbols': symbols,
          'timeframes': ['M5'],
          'intervalSeconds': 60
        }));
      setState(() => monitorStatus = r.statusCode == 200
        ? (monitorEnabled ? 'Monitoring ON' : 'Monitoring OFF')
        : 'Could not update monitor');
    } catch (e) { setState(() => monitorStatus = 'Monitor connection error'); }
  }

  Future<void> runMonitorOnce() async {
    setState(() => monitorStatus = 'Checking...');
    try {
      final r = await http.post(Uri.parse('$apiBase/monitor/run-once'));
      if (r.statusCode == 200) {
        final x = jsonDecode(r.body);
        setState(() => monitorStatus = 'Checked ${x['results']?.length ?? 0} symbol/timeframe combinations.');
        await loadHistory();
      } else {
        setState(() => monitorStatus = jsonDecode(r.body)['error'] ?? 'Monitor failed');
      }
    } catch (e) { setState(() => monitorStatus = 'Monitor connection error'); }
  }

  Future<void> testTelegram() async {
    try {
      final r = await http.post(Uri.parse('$apiBase/telegram/test'),
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({'text':'My Forex AI V10 Telegram test — ${symbol.text}'}));
      setState(() => result = r.statusCode == 200 ? 'Telegram test sent.' : (jsonDecode(r.body)['error'] ?? 'Telegram error'));
    } catch (e) { setState(() => result = 'Telegram error: $e'); }
  }

  Future<void> loadHistory() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/history'));
      if (r.statusCode == 200) setState(() => history = jsonDecode(r.body)['items'] ?? []);
    } catch (e) { setState(() => result = 'History error: $e'); }
  }

  Future<void> clearHistory() async {
    try {
      final r = await http.delete(Uri.parse('$apiBase/history'));
      if (r.statusCode == 200) setState(() => history = []);
    } catch (e) { setState(() => result = 'History error: $e'); }
  }

  Future<void> loadStrategies() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/strategies'));
      if (r.statusCode == 200) setState(() => files = jsonDecode(r.body)['files'] ?? []);
    } catch (e) { setState(() => result = 'Connection error: $e'); }
  }

  Future<void> toggleStrategy(dynamic f, bool enabled) async {
    try {
      final r = await http.patch(
        Uri.parse('$apiBase/strategies/${f['id']}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'enabled': enabled}),
      );
      if (r.statusCode == 200) await loadStrategies();
      else setState(() => result = 'Could not change strategy: ${r.body}');
    } catch (e) { setState(() => result = 'Connection error: $e'); }
  }

  Future<void> uploadStrategy() async {
    final pick = await FilePicker.platform.pickFiles();
    if (pick == null || pick.files.single.path == null) return;
    setState(() => busy = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$apiBase/strategies/upload'));
      req.files.add(await http.MultipartFile.fromPath('file', pick.files.single.path!));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      if (res.statusCode >= 200 && res.statusCode < 300) {
        await loadStrategies();
        setState(() => result = 'Strategy uploaded and indexed.');
      } else { setState(() => result = 'Upload error: $body'); }
    } catch (e) { setState(() => result = 'Upload error: $e'); }
    setState(() => busy = false);
  }

  Future<void> analyze() async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (image == null) return;
    setState(() { busy = true; result = ''; });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$apiBase/analyze'));
      req.fields['symbol'] = symbol.text.trim();
      req.fields['timeframe'] = tf;
      req.fields['question'] = question.text.trim();
      final selected = files.where((x) => x['status'] == 'completed' && x['enabled'] != false).map((x) => x['id']).toList();
      if (selected.isEmpty) {
        setState(() => result = 'Enable at least one completed strategy first.');
        setState(() => busy = false);
        return;
      }
      req.fields['strategyIds'] = jsonEncode(selected);
      req.files.add(await http.MultipartFile.fromPath('chart', image.path));
      final res = await req.send();
      final body = await res.stream.bytesToString();
      final data = jsonDecode(body);
      setState(() => result = res.statusCode == 200 ? (data['result'] ?? '') : (data['error'] ?? body));
    } catch (e) { setState(() => result = 'Analysis error: $e'); }
    setState(() => busy = false);
  }

  @override void initState() { super.initState(); _loadApiBaseAndData(); }

  Future<void> _loadApiBaseAndData() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('api_base_url');
    if (saved != null && saved.trim().isNotEmpty) apiBase = saved.trim().replaceAll(RegExp(r'/+$'), '');
    if (mounted) setState(() {});
    await Future.wait([loadStrategies(), loadHistory(), loadMonitor()]);
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Forex AI V11'), actions: [IconButton(onPressed: _settings, icon: const Icon(Icons.settings))]),
      body: IndexedStack(index: tab, children: [_ai(), _strategies(), _history(), _live(), _monitor()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.analytics), label: 'Analyze'),
          NavigationDestination(icon: Icon(Icons.library_books), label: 'Strategies'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.monitor_heart), label: 'Monitor'),
        ],
      ),
    );
  }

  Widget _ai() => ListView(padding: const EdgeInsets.all(16), children: [
    TextField(controller: symbol, decoration: const InputDecoration(labelText: 'Symbol')),
    const SizedBox(height: 10),
    DropdownButtonFormField<String>(value: tf, decoration: const InputDecoration(labelText: 'Timeframe'),
      items: ['M1','M5','M15','M30','H1','H4','D1'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
      onChanged:(v)=>setState(()=>tf=v!)),
    const SizedBox(height: 10),
    TextField(controller: question, maxLines: 3, decoration: const InputDecoration(
      labelText: 'Question (optional)', hintText: 'Check all my uploaded strategies for a valid setup')),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: busy ? null : analyze, icon: const Icon(Icons.image_search), label: Text(busy ? 'Analyzing...' : 'Upload Chart & Analyze')),
    const SizedBox(height: 20),
    if (result.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(result))),
  ]);

  Widget _strategies() => RefreshIndicator(
    onRefresh: loadStrategies,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      FilledButton.icon(onPressed: busy ? null : uploadStrategy, icon: const Icon(Icons.upload_file), label: const Text('Upload Strategy File')),
      const SizedBox(height: 12),
      Text('Indexed strategy files: ${files.length}', style: Theme.of(context).textTheme.titleMedium),
      ...files.map((f) => Card(child: ListTile(
        leading: Icon(f['status'] == 'completed' ? Icons.check_circle : Icons.hourglass_top),
        title: Text(f['filename'] ?? 'Unknown'),
        subtitle: Text('Status: ${f['status'] ?? 'unknown'}'),
        trailing: f['status'] == 'completed'
          ? Switch(value: f['enabled'] != false, onChanged: (v) => toggleStrategy(f, v))
          : null,
      ))),
    ]),
  );

  Widget _history() => RefreshIndicator(
    onRefresh: loadHistory,
    child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Text('Signal History', style: Theme.of(context).textTheme.titleLarge),
          const Spacer(),
          TextButton(onPressed: history.isEmpty ? null : clearHistory, child: const Text('Clear')),
        ]),
        const SizedBox(height: 8),
        if (history.isEmpty) const Text('No analyses yet.'),
        ...history.map((h) => Card(
          child: ExpansionTile(
            title: Text('${h['symbol'] ?? ''} — ${h['timeframe'] ?? ''}'),
            subtitle: Text((h['createdAt'] ?? '').toString()),
            childrenPadding: const EdgeInsets.all(16),
            children: [SelectableText(h['result'] ?? '')],
          ),
        )),
      ],
    ),
  );

  Widget _live() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text('Live Market', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 16),
      Card(child: ListTile(
        title: Text(symbol.text),
        subtitle: Text(marketStatus),
        trailing: Text(livePrice, style: Theme.of(context).textTheme.titleMedium),
      )),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: loadLivePrice, icon: const Icon(Icons.refresh), label: const Text('Refresh Live Price')),
      const SizedBox(height: 12),
      const Text('Live market data is optional. The AI uses your uploaded strategy files as the strategy source of truth.'),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: testTelegram, icon: const Icon(Icons.send), label: const Text('Test Telegram')),
    ],
  );

  Widget _monitor() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text('Automatic Monitor', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      const Text('V10 checks configured symbols against your enabled strategy library. BUY/SELL results can be sent to Telegram.'),
      const SizedBox(height: 16),
      TextField(controller: monitorSymbols, decoration: const InputDecoration(
        labelText: 'Symbols (comma separated)', hintText: 'XAU/USD,EUR/USD')),
      const SizedBox(height: 12),
      SwitchListTile(
        title: const Text('Monitoring enabled'),
        subtitle: Text(monitorStatus),
        value: monitorEnabled,
        onChanged: (v) { setState(() => monitorEnabled = v); saveMonitor(); },
      ),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: saveMonitor, icon: const Icon(Icons.save), label: const Text('Save Monitor')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: runMonitorOnce, icon: const Icon(Icons.play_arrow), label: const Text('Run Check Now')),
    ],
  );

  Future<void> _settings() async {
    final controller = TextEditingController(text: apiBase);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Backend URL'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            labelText: 'API base URL',
            hintText: 'https://your-backend.example.com',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Save')),
        ],
      ),
    );
    if (value == null || value.trim().isEmpty) return;
    final next = value.trim().replaceAll(RegExp(r'/+$'), '');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_base_url', next);
    setState(() { apiBase = next; result = 'Backend URL saved: $apiBase'; });
  }

}
