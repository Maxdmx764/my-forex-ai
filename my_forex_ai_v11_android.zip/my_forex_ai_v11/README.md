# My Forex AI V11

Android signal assistant based on uploaded strategy files. This is analysis-only: it does not place trades.

## What V11 includes
- Upload PDF/strategy files to the backend and index them with OpenAI File Search.
- Enable/disable individual strategies.
- Upload a chart screenshot and receive BUY / SELL / WAIT with entry, SL, TP, rule checks, invalidation and source files.
- Analysis history.
- Optional Twelve Data live price/OHLC context.
- Optional Telegram test/signals.
- Optional backend monitor endpoint.
- Android app lets you change the backend URL from Settings.
- GitHub Actions builds a release APK automatically.

## Important
The APK cannot be compiled in this workspace because Flutter/Android build tools are not installed here. The included GitHub Actions workflow performs the Android build in a hosted runner using the Flutter SDK.

## Build APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository.
3. Push to the `main` branch, or open **Actions → Build My Forex AI APK → Run workflow**.
4. Open the completed workflow run.
5. Download the artifact named `my-forex-ai-apk`.
6. Inside it is `app-release.apk`.

Flutter's official release documentation confirms `flutter build apk` produces the release APK under `build/app/outputs/flutter-apk/`. 

## Backend
Deploy `backend/` to a Node host such as Render, then configure the environment variables from `backend/.env.example`.

Keep the OpenAI API key only on the backend. Never put it in the Android app.

## First app setup
1. Install the APK.
2. Open Settings (gear icon).
3. Enter your deployed backend URL, for example `https://your-backend.example.com`.
4. Upload your strategy files.
5. Enable the strategies you want.
6. Upload a chart screenshot and analyze it.
